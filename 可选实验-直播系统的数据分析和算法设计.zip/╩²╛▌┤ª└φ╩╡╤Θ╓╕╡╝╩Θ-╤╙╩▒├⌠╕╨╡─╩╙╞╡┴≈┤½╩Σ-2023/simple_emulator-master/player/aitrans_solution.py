from player.packet_selection import Solution as Packet_selection
from player.examples.reno import Reno


class Solution(Reno, Packet_selection):
    pass
